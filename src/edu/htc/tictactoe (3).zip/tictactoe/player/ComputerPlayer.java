package edu.htc.tictactoe.player;

import edu.htc.tictactoe.strategy.BestOpenMoveStrategy;
import edu.htc.tictactoe.strategy.BlockWinStrategy;
import edu.htc.tictactoe.strategy.RandomMoveStrategy;
import edu.htc.tictactoe.strategy.TicTacToeStrategy;
import edu.htc.tictactoe.TicTacToe;


/**
 * Created by KenN on 2/22/16.
 */
public class ComputerPlayer extends Player{
    int answer = 1;

    public ComputerPlayer(String name,char marker) {
        super.name = name;
        super.gameMarker = marker;
    }

    public int getMove(){

        switch (TicTacToe.levelOfPlay){
            case 1:
                TicTacToeStrategy strategy = new RandomMoveStrategy();
                answer = strategy.getBestMove(); //get move from computer
                break;
            case 2:
                strategy = new BestOpenMoveStrategy();
                answer = strategy.getBestMove(); //get move from computer
                break;
            case 3:
                strategy = new BlockWinStrategy();
                answer = strategy.getBestMove('X'); //get move from computer that block any win / get best open
                if (answer == -1) {
                    TicTacToeStrategy strategy2 = new BestOpenMoveStrategy();
                answer = strategy2.getBestMove(); //get move from computer
                }
                break;
            case 4:

            default:
                strategy = new RandomMoveStrategy();
                answer = strategy.getBestMove(); //get move from computer
                break;

        }
        System.out.println("computer selects " + answer);
        return answer;
    }
}